package com.magic;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Controller {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
		//achieve the connectionn
		EntityManager em=emf.createEntityManager();
		//in built methods to perform CRUD operations
		//1.persist 2.find 3.remove 4.merge
		EntityTransaction et=em.getTransaction();
//		Dept d1=new Dept();
		Emp e1=new Emp();
		//to perform transactions
		//1.begin 2.commit
//		d1.setD_id(1);
//		d1.setD_name("cs");
//		d1.setLoc("hyd");
		e1.setE_name("Prem");
		e1.setSal(50000);
		e1.setJob("Developer");
		et.begin();
		//em.persist(d1)
		em.persist(e1);
		et.commit();
	}

}
